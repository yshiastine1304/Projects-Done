<!DOCTYPE html>
<html>
<head>
    <title>Teacher Signup</title>
    <!-- Include necessary CSS and JS files here -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-jgrowl/1.4.7/jquery.jgrowl.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-jgrowl/1.4.7/jquery.jgrowl.min.css">
</head>
<body>
    <form id="signin_teacher" class="form-signin" method="post" action="teacher_signup.php">
        <h3 class="form-signin-heading"><i class="icon-lock"></i> Sign up as Teacher</h3>
        <input type="text" class="input-block-level" name="firstname" placeholder="Firstname" required>
        <input type="text" class="input-block-level" name="lastname" placeholder="Lastname" required>
        <label>Department</label>
        <select id="department_id" name="department_id" class="input-block-level span12">
            <option value="">Select Department</option>
            <?php
            include('admin/dbcon.php'); // Include database connection file
            $query = mysqli_query($conn, "SELECT * FROM department ORDER BY department_name") or die(mysqli_error($conn));
            while ($row = mysqli_fetch_array($query)) {
                echo '<option value="' . $row['department_id'] . '">' . $row['department_name'] . '</option>';
            }
            ?>
        </select>
        <input type="text" class="input-block-level" id="username" name="username" placeholder="Username" required>
        <input type="password" class="input-block-level" id="password" name="password" placeholder="Password" required>
        <input type="password" class="input-block-level" id="cpassword" name="cpassword" placeholder="Confirm Password" required>
        <button id="signin" name="login" class="btn btn-info" type="submit"><i class="icon-check icon-large"></i> Sign Up</button>
        <p>Already have an account? <a href="index.php">Login</a></p>
    </form>
    <script>
        $(document).ready(function(){
            $("#signin_teacher").submit(function(e){
                e.preventDefault();
                var formData = $(this).serialize();
                $.ajax({
                    type: "POST",
                    url: "teacher_signup.php",
                    data: formData,
                    success: function(response){
                        if(response.trim() === 'true') {
                            alert("Successfully registered");
                            window.location = 'index.php';
                        } else {
                            alert("Registration failed");
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>
