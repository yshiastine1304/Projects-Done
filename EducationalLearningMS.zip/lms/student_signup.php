<?php
include('admin/dbcon.php');
session_start();

if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['class_id'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $class_id = $_POST['class_id'];

    // Insert student data into the database
    $insertQuery = "INSERT INTO student (username, password, firstname, lastname, class_id, status) VALUES (?, ?, ?, ?, ?, 'Registered')";
    $insertStmt = $conn->prepare($insertQuery);
    $insertStmt->bind_param("ssssi", $username, $password, $firstname, $lastname, $class_id);
    
    if($insertStmt->execute()) {
        $insertStmt->close();
        $_SESSION['id'] = $conn->insert_id; // Store the student ID in the session
        echo 'true';
    } else {
        echo 'false';
    }
} else {
    echo 'false';
}
?>
