<?php
include('admin/dbcon.php');

if(isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['username']) && isset($_POST['password']) && isset($_POST['department_id'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $password = $_POST['password']; // Password is plain text here
    $department_id = $_POST['department_id'];

    // Prepare and execute the SQL query to insert into the teacher table
    $query = "INSERT INTO teacher (firstname, lastname, username, password, department_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssi", $firstname, $lastname, $username, $password, $department_id);
    $stmt->execute();

    if($stmt->affected_rows > 0) {
        echo 'true'; // Signup success
        exit; // Stop further execution
    } else {
        echo 'false'; // Signup failed
    }

    $stmt->close();
} else {
    echo 'false'; // Missing POST data
}
?>
