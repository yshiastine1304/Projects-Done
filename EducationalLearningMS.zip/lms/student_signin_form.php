<!DOCTYPE html>
<html>
<head>
    <title>Student Signup</title>
    <!-- Include necessary CSS and JS files here -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-jgrowl/1.4.7/jquery.jgrowl.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-jgrowl/1.4.7/jquery.jgrowl.min.css">
</head>
<body>
    <form id="signup_student_form" class="form-signin" method="post" action="student_signup.php">
        <h3 class="form-signin-heading"><i class="icon-lock"></i> Sign up as Student</h3>
        <input type="text" class="input-block-level" id="username" name="username" placeholder="ID Number" required>
        <input type="text" class="input-block-level" id="firstname" name="firstname" placeholder="Firstname" required>
        <input type="text" class="input-block-level" id="lastname" name="lastname" placeholder="Lastname" required>
        <label>Class</label>
        <select name="class_id" class="input-block-level span5">
            <option value="">Select Class</option>
            <?php
            include('admin/dbcon.php');
            $query = mysqli_query($conn, "SELECT * FROM class ORDER BY class_name") or die(mysqli_error($conn));
            while ($row = mysqli_fetch_array($query)) {
                echo '<option value="' . $row['class_id'] . '">' . $row['class_name'] . '</option>';
            }
            ?>
        </select>
        <input type="password" class="input-block-level" id="password" name="password" placeholder="Password" required>
        <input type="password" class="input-block-level" id="cpassword" name="cpassword" placeholder="Confirm Password" required>
        <button id="signup_student" name="signup" class="btn btn-info" type="submit"><i class="icon-check icon-large"></i> Sign Up</button>
        <p>Already have an account? <a href="index.php">Login</a></p>
    </form>
    <script>
    $(document).ready(function(){
        $("#signup_student_form").submit(function(e){
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                type: "POST",
                url: "student_signup.php",
                data: formData,
                success: function(response){
                    if(response.trim() === 'true') {
                        alert("Successfully registered");
                        window.location = 'index.php';
                    } else {
                        alert("Registration failed");
                    }
                },
                error: function(xhr, status, error) {
                    alert("Error: " + error);
                }
            });
        });
    });
    </script>
</body>
</html>
