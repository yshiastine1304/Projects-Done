<div class="pull-right">
		<footer>
           <p>Programmed by: Darrenjayk Gutang</p>
        <footer>
</div>