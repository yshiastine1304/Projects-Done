<?php
// Assuming you have already established a database connection
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "";
$database = "reymart.event_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the email from the request
$email = $_GET['email'];

// Prepare SQL statement to check if email exists
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();

// Close the database connection
$conn->close();

// Send response as JSON
header('Content-Type: application/json');

// Check if email exists
if ($count > 0) {
    echo json_encode(array("exists" => true));
} else {
    echo json_encode(array("exists" => false));
}
?>
