<?php
// Include your database connection file
include 'db_connection.php';

// Fetch users from the database
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// Check if there are any users
if ($result->num_rows > 0) {
    echo '<h2>Users</h2>';
    echo '<div class="dashboard-content">';
    echo '<ul>';
    // Output each user
    while ($row = $result->fetch_assoc()) {
        echo '<li>' . $row['name'] . ' - ' . $row['email'] . '</li>';
    }
    echo '</ul>';
    echo '</div>';
} else {
    // If no users found, display a message
    echo '<h2>Users</h2>';
    echo '<div class="dashboard-content">';
    echo '<p>No users found.</p>';
    echo '</div>';
}

// Close the database connection
$conn->close();
?>
