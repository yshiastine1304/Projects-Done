<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.css">
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f9fa;
    }

    .sidebar {
        position: fixed;
        left: 0;
        top: 0;
        height: 100%;
        width: 250px;
        background-color: #343a40;
        padding-top: 20px;
        transition: width 0.5s;
        overflow-y: auto;
    }

    .sidebar ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        padding: 10px 20px;
        border-bottom: 1px solid #495057;
    }

    .sidebar ul li a {
        text-decoration: none;
        color: #ffffff;
        display: block;
    }

    .sidebar ul li a i {
        margin-right: 10px;
    }

    .sidebar ul li.active {
        background-color: #007bff;
    }

    .sidebar ul li.active a {
        color: #ffffff;
    }

    .content {
        margin-left: 250px;
        padding: 20px;
    }

    h1 {
        color: #343a40;
    }

    .card {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    .card h2 {
        color: #343a40;
    }

    .card-content {
        margin-top: 20px;
    }

    .card-content p {
        margin-bottom: 10px;
    }

    canvas {
        max-width: 100%;
    }
</style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <ul>
        <li class="active"><a href="#" onclick="toggleSidebar()"><i class="fas fa-bars"></i></a></li>
        <li><a href="#" onclick="setActive(this)"><i class="fas fa-calendar-alt"></i>Events</a></li>
        <li><a href="#" onclick="setActive(this)"><i class="fas fa-ticket-alt"></i>Tickets</a></li>
        <li><a href="#" onclick="setActive(this)"><i class="fas fa-user"></i>Users</a></li>
        <li><a href="#" onclick="setActive(this)"><i class="fas fa-map-marker-alt"></i>Venues</a></li>
        <li><a href="#" onclick="setActive(this)"><i class="fas fa-bullhorn"></i>Promotions</a></li>
        <li><a href="#" onclick="setActive(this)"><i class="fas fa-chart-line"></i>Analytics</a></li>
        <li><a href="#" onclick="setActive(this)"><i class="fas fa-cog"></i>Settings</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
    </ul>
</div>

<div class="content">
    <h1>Admin Dashboard</h1>
    <div class="card">
        <h2>Event Overview</h2>
        <div class="card-content">
            <p>Total Events: <span id="totalEvents">Loading...</span></p>
            <p>Total Tickets Sold: <span id="totalTickets">Loading...</span></p>
            <p>Total Revenue: <span id="totalRevenue">Loading...</span></p>
        </div>
    </div>
    <div class="card">
        <h2>User Overview</h2>
        <div class="card-content">
            <p>Total Users: <span id="totalUsers">Loading...</span></p>
            <p>Active Users: <span id="activeUsers">Loading...</span></p>
            <p>Admin Users: <span id="adminUsers">Loading...</span></p>
        </div>
    </div>
    <div class="card">
        <h2>Event Analytics</h2>
        <canvas id="eventAnalyticsChart"></canvas>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.style.width = sidebar.style.width === '250px' ? '70px' : '250px';
    }

    function setActive(element) {
        const lis = document.querySelectorAll('.sidebar ul li');
        lis.forEach(li => li.classList.remove('active'));
        element.parentElement.classList.add('active');
    }

    // Simulated data loading (replace with actual data retrieval)
    setTimeout(() => {
        document.getElementById('totalEvents').innerText = '100';
        document.getElementById('totalTickets').innerText = '5000';
        document.getElementById('totalRevenue').innerText = '$100,000';
        document.getElementById('totalUsers').innerText = '1000';
        document.getElementById('activeUsers').innerText = '800';
        document.getElementById('adminUsers').innerText = '5';

        // Chart data
        const eventAnalyticsData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Ticket Sales',
                data: [150, 200, 250, 300, 350, 400],
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        };

        const eventAnalyticsOptions = {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        };

        const eventAnalyticsChart = new Chart(document.getElementById('eventAnalyticsChart'), {
            type: 'bar',
            data: eventAnalyticsData,
            options: eventAnalyticsOptions
        });
    }, 1000); // Simulated delay for data loading
</script>

</body>
</html>
