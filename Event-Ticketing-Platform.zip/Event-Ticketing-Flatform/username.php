<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fullname = $_POST["fullname"];
    $username = $_POST["username"]; // New line to retrieve username
    $contact = $_POST["contact"];
    $address = $_POST["address"];
    $usertype = $_POST["usertype"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Perform any necessary validation here

    // Now, you would typically insert the data into a database
    // For example, using PDO (PHP Data Objects)
    $dsn = "mysql:host=localhost;dbname=your_database_name";
    $username_db = "your_database_username"; // Changed variable name to avoid conflict
    $password_db = "your_database_password"; // Changed variable name to avoid conflict

    try {
        $pdo = new PDO($dsn, $username_db, $password_db); // Updated variable names
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare SQL statement
        $stmt = $pdo->prepare("INSERT INTO users (fullname, username, contact, address, usertype, email, password) VALUES (?, ?, ?, ?, ?, ?, ?)");

        // Bind parameters
        $stmt->bindParam(1, $fullname);
        $stmt->bindParam(2, $username); // New line to bind username
        $stmt->bindParam(3, $contact);
        $stmt->bindParam(4, $address);
        $stmt->bindParam(5, $usertype);
        $stmt->bindParam(6, $email);
        $stmt->bindParam(7, $password);

        // Execute the statement
        $stmt->execute();

        // Redirect user to a success page
        header("Location: registration_success.php");
        exit();
    } catch (PDOException $e) {
        // Handle database errors
        echo "Error: " . $e->getMessage();
    }

    // Close the connection
    $pdo = null;
}
?>