<?php
// Start the session
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form is for login or OTP verification
    if (isset($_POST['email']) && isset($_POST['password']) && isset($_POST['otp'])) {
        // This part is for OTP verification
        $email = $_POST['email'];
        $otp = $_POST['otp'];

        // Verify the OTP here (You need to implement this part)
        // Assume $otpVerified is a boolean variable indicating whether the OTP is valid

        if ($otpVerified) {
            // If OTP is verified, redirect to admin dashboard
            header("Location: admin_dashboard.php");
            exit;
        } else {
            // If OTP is not verified, show an error message
            $error = "Invalid OTP. Please try again.";
        }
    } elseif (isset($_POST['email'])) {
        // This part is for sending OTP
        $email = $_POST['email'];

        // Generate OTP (You need to implement this part)
        $otp = generateOTP(); // Assuming you have a function to generate OTP

        // Send OTP to the user's email (You need to implement this part)

        // Store OTP in session for verification
        $_SESSION['otp'] = $otp;
        $_SESSION['email'] = $email;

        // Redirect to OTP verification page
        header("Location: otp_verification.php");
        exit;
    }
}

// Function to generate OTP
function generateOTP() {
    // Generate a random 6-digit OTP
    return rand(100000, 999999);
}
?>
