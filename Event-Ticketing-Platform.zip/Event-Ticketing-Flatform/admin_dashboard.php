<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Planning Ticketing - Administrator Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Your CSS styles here */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }
        .sidebar a {
            padding: 10px 20px;
            text-decoration: none;
            font-size: 18px;
            color: #fff;
            display: block;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px; /* Added margin between buttons */
        }
        .sidebar a:hover {
            background-color: #555;
        }
        .sidebar a i {
            margin-right: 10px;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
        .content h2 {
            color: #333;
        }
        .dashboard-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        /* Add more styling for specific dashboard elements as needed */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #333;
            color: white;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .button:hover {
            background-color: #45a049;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            border-radius: 5px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <a href="#" onclick="showDashboard()"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
    <a href="#" onclick="showEvents()"><i class="fas fa-calendar-alt"></i>Events</a>
    <a href="#" onclick="showTickets()"><i class="fas fa-ticket-alt"></i>Tickets</a>
    <a href="#" onclick="showUsers()"><i class="fas fa-users"></i>Users</a>
    <a href="#" onclick="showPayments()"><i class="fas fa-money-bill-alt"></i>Payments</a>
    <a href="#" onclick="showReports()"><i class="fas fa-chart-bar"></i>Reports</a>
    <a href="#" onclick="showSettings()"><i class="fas fa-cog"></i>Settings</a>
    <a href="#" onclick="showSupport()"><i class="fas fa-life-ring"></i>Support</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</div>

<div class="content" id="content">
    <!-- Content will be dynamically updated based on sidebar button clicks -->
</div>

<!-- Event Modal -->
<div id="eventModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeEventModal()">&times;</span>
        <h2>Create/Edit Event</h2>
        <form id="eventForm" onsubmit="saveEvent(event)">
            <label for="eventName">Event Name:</label><br>
            <input type="text" id="eventName" name="eventName" required><br><br>
            <label for="eventDate">Event Date:</label><br>
            <input type="date" id="eventDate" name="eventDate" required><br><br>
            <label for="eventVenue">Event Venue:</label><br>
            <input type="text" id="eventVenue" name="eventVenue" required><br><br>
            <button type="submit" class="button">Save</button>
        </form>
    </div>
</div>

<!-- Ticket Modal -->
<div id="ticketModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeTicketModal()">&times;</span>
        <h2>Create/Edit Ticket</h2>
        <!-- Add form fields for ticket creation/editing -->
    </div>
</div>

<script>
    // Sample events and tickets data
    let eventsData = [];
    let ticketsData = [];

    function showDashboard() {
        document.getElementById('content').innerHTML = `
            <h2>Dashboard</h2>
            <div class="dashboard-content">
                <!-- Your dashboard HTML content here -->
                <h3>Welcome, Admin!</h3>
                <p>This is your admin dashboard where you can manage various aspects of your event planning ticketing platform.</p>
                <ul>
                    <li>Manage events</li>
                    <li>Manage tickets</li>
                    <li>Manage users</li>
                    <li>Manage payments</li>
                    <li>Generate reports</li>
                    <li>Configure settings</li>
                    <li>Get support</li>
                </ul>
            </div>
        `;
    }
    
    function showEvents() {
        document.getElementById('content').innerHTML = `
            <h2>Events</h2>
            <div class="dashboard-content">
                <button class="button" onclick="openEventModal()">Create Event</button>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Date</th>
                            <th>Venue</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="eventsTableBody">
                        <!-- Event details will be dynamically added here -->
                    </tbody>
                </table>
            </div>
        `;
        displayEvents();
    }
    
    function showTickets() {
        document.getElementById('content').innerHTML = `
            <h2>Tickets</h2>
            <div class="dashboard-content">
                <button class="button" onclick="openTicketModal()">Create Ticket</button>
                <table>
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>Event</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="ticketsTableBody">
                        <!-- Ticket details will be dynamically added here -->
                    </tbody>
                </table>
            </div>
        `;
        displayTickets();
    }

    // Define other show functions similarly for Users, Payments, Reports, Settings, Support
    function showUsers() {
        document.getElementById('content').innerHTML = `
            <h2>Users</h2>
            <div class="dashboard-content">
                <p>Manage users here.</p>
            </div>
        `;
    }

    function showPayments() {
        document.getElementById('content').innerHTML = `
            <h2>Payments</h2>
            <div class="dashboard-content">
                <p>Manage payments here.</p>
            </div>
        `;
    }

    function showReports() {
        document.getElementById('content').innerHTML = `
            <h2>Reports</h2>
            <div class="dashboard-content">
                <p>Generate reports here.</p>
            </div>
        `;
    }

    function showSettings() {
        document.getElementById('content').innerHTML = `
            <h2>Settings</h2>
            <div class="dashboard-content">
                <p>Configure settings here.</p>
            </div>
        `;
    }

    function showSupport() {
        document.getElementById('content').innerHTML = `
            <h2>Support</h2>
            <div class="dashboard-content">
                <p>Get support here.</p>
            </div>
        `;
    }

    function openEventModal() {
        document.getElementById('eventModal').style.display = "block";
    }

    function closeEventModal() {
        document.getElementById('eventModal').style.display = "none";
    }

    function openTicketModal() {
        document.getElementById('ticketModal').style.display = "block";
    }

    function closeTicketModal() {
        document.getElementById('ticketModal').style.display = "none";
    }

    function saveEvent(event) {
        event.preventDefault(); // Prevent form submission
        let eventName = document.getElementById('eventName').value;
        let eventDate = document.getElementById('eventDate').value;
        let eventVenue = document.getElementById('eventVenue').value;
        
        // Create new event object
        let newEvent = {
            id: eventsData.length + 1, // Generate unique ID (you may use a more robust method)
            name: eventName,
            date: eventDate,
            venue: eventVenue
        };

        // Add new event to eventsData array
        eventsData.push(newEvent);

        // Close modal
        closeEventModal();

        // Display updated events
        displayEvents();
    }

    function saveTicket(event) {
        event.preventDefault(); // Prevent form submission
        // Retrieve and process ticket data
        // Add new ticket to ticketsData array
        // Close modal
        closeTicketModal();
        // Display updated tickets
    }

    function displayEvents() {
        let eventsTableBody = document.getElementById('eventsTableBody');
        eventsTableBody.innerHTML = ''; // Clear existing table rows
        for (let event of eventsData) {
            let row = `
                <tr>
                    <td>${event.name}</td>
                    <td>${event.date}</td>
                    <td>${event.venue}</td>
                    <td>
                        <button class="button" onclick="openEditEventModal(${event.id})">Edit</button>
                        <button class="button" onclick="deleteEvent(${event.id})">Delete</button>
                    </td>
                </tr>`;
            eventsTableBody.innerHTML += row;
        }
    }

    function displayTickets() {
        let ticketsTableBody = document.getElementById('ticketsTableBody');
        ticketsTableBody.innerHTML = ''; // Clear existing table rows
        for (let ticket of ticketsData) {
            let row = `
                <tr>
                    <td>${ticket.id}</td>
                    <td>${ticket.event}</td>
                    <td>${ticket.price}</td>
                    <td>${ticket.quantity}</td>
                    <td>${ticket.status}</td>
                    <td>
                        <button class="button" onclick="openEditTicketModal(${ticket.id})">Edit</button>
                        <button class="button" onclick="deleteTicket(${ticket.id})">Delete</button>
                    </td>
                </tr>`;
            ticketsTableBody.innerHTML += row;
        }
    }
</script>

</body>
</html>
