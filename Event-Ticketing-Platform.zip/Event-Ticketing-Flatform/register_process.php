<?php
// Start session
session_start();

// Include database connection script
include 'db_con.php'; // Assuming you have created the db_connection.php file

// Function to validate email
function validate_email($email) {
    // Check if email is valid
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Check if form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fullname = $_POST['fullname'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password']; // New field for password confirmation
    $usertype = $_POST['usertype']; // New field for user type
    
    // Escape user inputs for security
    $fullname = mysqli_real_escape_string($conn, $fullname);
    // Check if full name already exists
    $query = "SELECT * FROM users WHERE name='$fullname'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        // Full name already exists
        echo "FULL NAME IS ALL READY TAKEN.";
    } else {
        // Full name is available, proceed with registration
        // Validate email
        if (!validate_email($email)) {
            // Invalid email format, display error message
            echo "<script>alert('Invalid email format. Please enter a valid email address.')</script>";
            echo "<script>window.location.href='register.php'</script>";
            exit();
        }

        // Check if username already exists
        $check_query = "SELECT * FROM users WHERE email = ?";
        $stmt_check = $conn->prepare($check_query);
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            // Username already exists, display JavaScript alert message
            echo "<script>alert('The email already registered. Please choose a different email.')</script>";
            // Redirect back to registration page
            echo "<script>window.location.href='register.php'</script>";
            exit();
        }

        // Check password length
        if (strlen($password) < 8) {
            // Password length is less than 8 characters, display error message
            echo "<script>alert('Password must be at least 8 characters long.')</script>";
            echo "<script>window.location.href='register.php'</script>";
            exit();
        }
        
        // Check if password and its confirmation match
        if ($password !== $confirm_password) {
            // Password and confirmation do not match, display error message
            echo "<script>alert('Password do not match.')</script>";
            echo "<script>window.location.href='register.php'</script>";
            exit();
        }

        // Check if password contains at least one letter, one number, and one special character
        if (!preg_match("/[a-zA-Z]/", $password) || !preg_match("/[0-9]/", $password) || !preg_match("/[^a-zA-Z0-9]/", $password)) {
            // Password doesn't meet requirements, display error message
            echo "<script>alert('Password must contain at least one letter, one number, and one special character.')</script>";
            echo "<script>window.location.href='register.php'</script>";
            exit();
        }

        // Hash the password for security (recommended)
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL statement to insert user into the database
        $sql = "INSERT INTO users (name, phone, address, email, password, user_type) VALUES (?, ?, ?, ?, ?, ?)";
        
        // Prepare and bind parameters
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $fullname, $contact, $address, $email, $hashed_password, $usertype);

        // Execute query
        if ($stmt->execute()) {

            // Display JavaScript alert for successful registration
            echo "<script>alert('Registration successful!')</script>";

            // Redirect to a welcome page or home page
            header("Location: index.php");
            exit();
        } else {
            // Redirect back to registration page with error message
            header("Location: register.php?error=1");
            exit();
        }
    }
}
?>
