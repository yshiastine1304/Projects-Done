<!DOCTYPE html>
<html>
<head>
    <title>Login form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            width: 400px;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            text-align: center;
        }

        .logo {
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"] {
            width: calc(100% - 40px);
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #dddfe2;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        button[type="submit"] {
            width: 40%;
            background-color: #1877f2;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-transform: uppercase;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #1469c9;
        }

        .forgot-password-link {
            display: block;
            text-align: right;
            margin-bottom: 10px;
            font-size: 14px;
            color: #1877f2;
            text-decoration: none;
        }

        .forgot-password-link:hover {
            text-decoration: underline;
        }

        .register-link {
            margin-top: 20px;
            font-size: 14px;
            color: #333;
        }

        .register-link a {
            color: #1877f2;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-container">
    <img class="logo" src="logo.png" alt="Event Ticketing Platform Logo" width="150">
    <form action="login_process.php" method="POST">
        <input type="text" id="email" name="email" placeholder="Email" required>
        <input type="password" id="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
        <a href="forgot-password.php" class="forgot-password-link">Forgot password?</a>
    </form>
    <div class="register-link">Don't have an account? <a href="register.php">Sign up</a>.</div>
</div>

</body>
</html>
