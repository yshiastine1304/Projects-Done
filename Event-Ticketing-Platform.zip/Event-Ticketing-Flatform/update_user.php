<!-- Modify the Users section content -->
<div class="dashboard-content">
    <h2>Users</h2>
    <!-- Display users from the database -->
    <?php include 'fetch_users.php'; ?>
    <!-- Add a form for adding users -->
    <form action="add_user.php" method="post">
        <!-- Add input fields for user data -->
        <input type="text" name="name" placeholder="Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <!-- Add more input fields as needed -->
        <button type="submit">Add User</button>
    </form>
    <!-- Add forms for updating and deleting users -->
    <!-- Update form -->
    <form action="update_user.php" method="post">
        <input type="hidden" name="user_id" value="user_id_to_update">
        <!-- Add input fields for updated user data -->
        <input type="text" name="name" placeholder="Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <!-- Add more input fields as needed -->
        <button type="submit">Update User</button>
    </form>
    <!-- Delete form -->
    <form action="delete_user.php" method="post">
        <input type="hidden" name="user_id" value="user_id_to_delete">
        <button type="submit">Delete User</button>
    </form>
</div>
