<!DOCTYPE html>
<html>

<head>
    <title>Forgot Password</title>
    <meta charset="UTF-8">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(to right, #743ad5, #d53a9d);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Poppins', sans-serif;
        }

        form {
            width: 400px;
            padding: 50px;
            border-radius: 20px;
            background-color: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #333;
            text-transform: uppercase;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input[type="email"],
        input[type="text"],
        input[type="password"] {
            width: calc(100% - 20px);
            padding: 12px;
            margin-bottom: 10px;
            border: none;
            border-radius: 5px;
            box-sizing: border-box;
            outline: none;
        }

        button[type="submit"],
        button[type="button"] {
            width: 100%;
            background-color: #743ad5;
            color: white;
            padding: 15px;
            margin-top: 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-transform: uppercase;
        }

        button[type="submit"]:hover,
        button[type="button"]:hover {
            background-color: #d53a9d;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #333;
            text-decoration: none;
        }

        .warning-message {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
        }

        .password-group {
            display: none;
        }

        .password-group.active {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .password-group.active label {
            flex: 1;
            color: #333;
        }

        .password-group.active input[type="password"] {
            width: calc(100% - 30px);
            padding: 12px;
            border: none;
            border-radius: 5px;
            box-sizing: border-box;
            outline: none;
        }

        .password-group.active input[type="checkbox"] {
            margin-left: 10px;
        }
    </style>
</head>

<body>

    <form id="forgotPasswordForm" method="post" action="verify-otp.php">
        <h1>Forgot Password</h1>
        <div id="emailSection">
            <label for="email">Email address</label>
            <input type="email" name="email" id="email" required>
            <button type="button" id="sendCodeBtn">Send Code</button>
        </div>

        <div class="verification-section" id="verificationSection" style="display: none;">
            <label for="otp">One Time Pin:</label>
            <input type="text" name="otp" id="otp" required>
            <button type="button" id="verifyBtn">Verify</button>
        </div>

        <div id="passwordSection" class="password-group">
            <label for="new_password">New Password:</label>
            <span id="passwordValidationMessage" class="warning-message"></span>
            <div>
                <input type="password" name="new_password" id="new_password" required>
                <input type="checkbox" id="showNewPasswordCheckbox" onclick="togglePasswordVisibility('new_password')">
            </div>
        </div>

        <div id="confirmPasswordSection" class="password-group">
            <label for="confirm_password">Confirm Password:</label>
            <span id="confirmPasswordValidationMessage" class="warning-message"></span>
            <span id="passwordMatchMessage" class="warning-message"></span>
            <div>
                <input type="password" name="confirm_password" id="confirm_password" required>
                <input type="checkbox" id="showConfirmPasswordCheckbox" onclick="togglePasswordVisibility('confirm_password')">
            </div>
        </div>

        <button type="submit" id="changePasswordBtn" style="display: none;">Change Password</button>

        <a href="index.php">Go back to Login</a>
    </form>

    <script>
        // JavaScript to send OTP when "Send Code" button is clicked
        document.getElementById('sendCodeBtn').addEventListener('click', function (e) {
            e.preventDefault(); // Prevent default button behavior
            var email = document.getElementById('email').value;
            // Validate email format (you can add more validation if needed)
            if (email.trim() === '' || !email.includes('@') || !email.includes('.')) {
                alert('Please enter a valid email address.');
                return;
            }
            // AJAX call to send OTP
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    alert('OTP sent, please check your email.');
                    document.getElementById('emailSection').style.display = 'none';
                    document.getElementById('verificationSection').style.display = 'block';
                }
            };
            xhr.open('POST', 'send-otp.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.send('email=' + encodeURIComponent(email));
        });

        // JavaScript to submit form when "Verify" button is clicked
        document.getElementById('verifyBtn').addEventListener('click', function (e) {
            e.preventDefault(); // Prevent default button behavior
            var otp = document.getElementById('otp').value;
            // You may need to validate OTP before proceeding
            if (otp.trim() === '') {
                alert('Please enter the verification code.');
                return;
            }
            // Hide verification section
            document.getElementById('verificationSection').style.display = 'none';
            // Show password section
            document.getElementById('passwordSection').style.display = 'block';
            document.getElementById('confirmPasswordSection').style.display = 'block';
            document.getElementById('changePasswordBtn').style.display = 'block';
        });

        // Password validation
        document.getElementById("new_password").addEventListener("input", function () {
            var passwordField = this;
            var password = passwordField.value;
            var passwordValidationMessage = document.getElementById("passwordValidationMessage");
            if (password.trim() === "") {
                passwordValidationMessage.textContent = "";
                return; // Exit the function if the password is empty
            }
            var requirements = checkPasswordRequirements(password);
            if (requirements.length > 0) {
                passwordValidationMessage.textContent = "Weak password: " + requirements.join(", ");
            } else {
                passwordValidationMessage.textContent = "Strong password";
            }
        });

        // Confirm password validation
        document.getElementById("confirm_password").addEventListener("input", function () {
            var confirmPasswordField = this;
            var confirmPassword = confirmPasswordField.value;
            var passwordField = document.getElementById("new_password");
            var password = passwordField.value;
            var confirmPasswordValidationMessage = document.getElementById("confirmPasswordValidationMessage");
            var passwordMatchMessage = document.getElementById("passwordMatchMessage");
            if (password !== confirmPassword) {
                confirmPasswordValidationMessage.textContent = "Passwords do not match.";
                passwordMatchMessage.textContent = "";
            } else {
                confirmPasswordValidationMessage.textContent = "";
                passwordMatchMessage.textContent = "Passwords match.";
            }
        });

        // Function to check password requirements
        function checkPasswordRequirements(password) {
            var requirements = [];
            if (password.length < 8) {
                requirements.push("at least 8 characters");
            }
            if (!/[A-Za-z]/.test(password)) {
                requirements.push("at least one letter");
            }
            if (!/\d/.test(password)) {
                requirements.push("at least one number");
            }
            if (!/[@$!%*#?&]/.test(password)) {
                requirements.push("at least one special character");
            }
            return requirements;
        }

        // Function to toggle password visibility
        function togglePasswordVisibility(inputId) {
            var passwordInput = document.getElementById(inputId);
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
    </script>

</body>

</html>
