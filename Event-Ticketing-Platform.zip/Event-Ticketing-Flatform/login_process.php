<?php
// Start session
session_start();

// Include database connection script
include 'db_con.php'; // Assuming you have created the db_connection.php file

// Check if form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL statement to select user with provided email
    $sql = "SELECT * FROM users WHERE email = ?";
    
    // Prepare and bind parameter
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);

    // Execute query
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows == 1) {
        // Fetch user data
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user['password'])) {
            // Reset failed login attempts
            $stmt = $conn->prepare("UPDATE users SET login_attempts = 0 WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            // Store user data in session
            $_SESSION['user'] = $user;

            // Redirect based on user type
            if ($user['user_type'] == 'Administrator') {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: welcome.php");
            }
            exit();
        } else {
            // Increment failed login attempts
            $failedAttempts = $user['login_attempts'] + 1;
            $stmt = $conn->prepare("UPDATE users SET login_attempts = ? WHERE email = ?");
            $stmt->bind_param("is", $failedAttempts, $email);
            $stmt->execute();

            // Check if failed attempts reached the limit
            if ($failedAttempts >= 3) {
                // Display message and redirect to forgot password page
                echo "<script>alert('You have exceeded the maximum number of login attempts. Please use the forgot password feature.')</script>";
                echo "<script>window.location.href='forgot-password.php'</script>";
                exit();
            } else {
                // Invalid password, display JavaScript alert message
                echo "<script>alert('Invalid password. Please try again.')</script>";
                // Redirect back to login page
                echo "<script>window.location.href='index.php'</script>";
                exit();
            }
        }
    } else {
        // Username does not exist, display JavaScript alert message
        echo "<script>alert('Email does not exist. Please register first.')</script>";
        // Redirect back to login page
        echo "<script>window.location.href='index.php'</script>";
        exit();
    }
}

?>
