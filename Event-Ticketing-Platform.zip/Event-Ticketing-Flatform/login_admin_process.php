<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if email and password are set and not empty
    if (isset($_POST['email']) && isset($_POST['password']) && !empty($_POST['email']) && !empty($_POST['password'])) {
        // Include database connection
        include_once 'db_connection.php';

        // Get email and password from form
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Prepare and execute SQL query to check if the user exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if user exists
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Password is correct, set session variables and redirect to appropriate page
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = $user['user_type'];
                if ($user['user_type'] == 'Administrator') {
                    header("Location: admin_home.php");
                    exit();
                } else {
                    header("Location: user_home.php");
                    exit();
                }
            } else {
                // Password is incorrect
                $_SESSION['login_error'] = "Incorrect password";
                header("Location: login.php");
                exit();
            }
        } else {
            // User does not exist
            $_SESSION['login_error'] = "User not found";
            header("Location: login.php");
            exit();
        }
    } else {
        // Email or password is not set or empty
        $_SESSION['login_error'] = "Email or password is empty";
        header("Location: login.php");
        exit();
    }
} else {
    // Redirect to login page if accessed directly
    header("Location: login.php");
    exit();
}
?>