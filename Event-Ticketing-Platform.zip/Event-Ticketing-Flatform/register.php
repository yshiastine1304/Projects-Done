<!DOCTYPE html>
<html>
<head>
    <title>Registration form</title>
    <style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
        *{  
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
       body {
    background: linear-gradient(to right, #743ad5, #d53a9d);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 110vh;
    margin: 0;
    font-family: 'Poppins', sans-serif;
}

form {
    width: 400px;
    padding: 70px;
    border-radius: 20px;
    background-color:  #fff;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
}

h2 {
    text-align: center;
    color: #333;
    text-transform: uppercase;
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 10px;
    color: #333;
}

input[type="text"],
input[type="password"] {
    width: calc(100% - 20px); /* Adjusted width to accommodate the checkbox */
    padding: 12px;
    margin-bottom: 10px;
    border: none;
    border-radius: 5px;
    box-sizing: border-box;
    outline: none; /* Removed outline */
}

button[type="submit"] {
    width: 100%;
    background-color: #743ad5;
    color: white;
    padding: 12px;
    margin-top: 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-transform: uppercase;
}

button[type="submit"]:hover {
    background-color: #d53a9d;
}

p {
    text-align: center;
    color: #333;
}

.warning-message {
    color: red;
    font-size: 14px;
    text-align: center;
    margin-top: 10px;
}

.password-group {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
}

.password-group label {
    flex: 1;
    color: #333;
}

.password-group input[type="password"] {
    width: calc(100% - 30px); /* Adjusted width to accommodate the checkbox */
    padding: 12px;
    border: none;
    border-radius: 5px;
    box-sizing: border-box;
    outline: none; /* Removed outline */
}

.password-group input[type="checkbox"] {
    margin-left: 10px;
}
    </style>
</head>
<body>

<form action="register_process.php" method="POST" class="grid-form">
    <div class="form-part">
        <h2>REGISTRATION FORM</h2>

        <label for="fullname">Full Name:</label>
        <input type="text" id="fullname" name="fullname" required>


        <label for="contact">Contact Number:</label>
        <span id="phoneValidationMessage" class="warning-message"></span>
        <input type="text" id="contact" name="contact" required>


        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required>

        <label for="usertype">User Type:</label>
        <select id="usertype" name="usertype" required>
            <option value="">Please Select</option>
            <option value="">Attendees</option>
            <option value="">Administrator</option>
            <option value="">Organizer</option>

        </select>
    </div>
    <div class="form-part">
        <label for="email">Email:</label>
        <span id="emailValidationMessage" class="warning-message"></span>
        <input type="text" id="email" name="email" required>


        <label for="password">Password:</label>
        <span id="passwordValidationMessage" class="warning-message"></span>
        <div class="password-group">
            <input type="password" id="password" name="password" required>
            <input type="checkbox" id="showPasswordCheckbox">
        </div>


        <label for="confirm_password">Confirm Password:</label>
        <span id="confirmPasswordValidationMessage" class="warning-message"></span>
        <span id="passwordMatchMessage" class="warning-message"></span>
        <div class="password-group">
            <input type="password" id="confirm_password" name="confirm_password" required>
            <input type="checkbox" id="showConfirmPasswordCheckbox">
        </div>


        <button type="submit" id="registerButton">Register</button>
        <p>Already have an account? <a href="index.php">Login here</a>.</p>
    </div>
</form>
<script>

    // Confirm password validation
    document.getElementById("confirm_password").addEventListener("input", function () {
        var confirmPasswordField = this;
        var confirmPassword = confirmPasswordField.value;
        var passwordField = document.getElementById("password");
        var password = passwordField.value;
        var confirmPasswordValidationMessage = document.getElementById("confirmPasswordValidationMessage");
        var passwordMatchMessage = document.getElementById("passwordMatchMessage");
        if (password !== confirmPassword) {
            confirmPasswordValidationMessage.textContent = "Passwords do not match.";
            passwordMatchMessage.textContent = "";
        } else {
            confirmPasswordValidationMessage.textContent = "";
            passwordMatchMessage.textContent = "Passwords match.";
        }
    });

    // Email format validation
    document.getElementById("email").addEventListener("input", function () {
        var emailField = this;
        var email = emailField.value.trim(); // Trim to remove leading and trailing whitespaces
        var emailValidationMessage = document.getElementById("emailValidationMessage");

        if (email === "") {
            // If email field is empty, clear the error message
            emailValidationMessage.textContent = "";
            return; // Exit the function
        }

        // Regular expression for email format validation
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(email)) {
            emailValidationMessage.textContent = "Invalid email format";
        } else {
            emailValidationMessage.textContent = "";

            // If email format is valid, check if it exists in the database
            checkEmailExists(email);
        }
    });

    // Confirm password validation
    document.getElementById("confirm_password").addEventListener("input", function () {
        var confirmPasswordField = this;
        var confirmPassword = confirmPasswordField.value;
        var passwordField = document.getElementById("password");
        var password = passwordField.value;
        var confirmPasswordValidationMessage = document.getElementById("confirmPasswordValidationMessage");
        if (password !== confirmPassword) {
            confirmPasswordValidationMessage.textContent = "Passwords do not match.";
        } else {
            confirmPasswordValidationMessage.textContent = "";
        }
    });

    // Function to check if email exists in the database
    function checkEmailExists(email) {
        // Make an AJAX request to the server to check email existence
        // Example using Fetch API
        fetch("check-email.php?email=" + encodeURIComponent(email))
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error('Network response was not ok.');
                }
            })
            .then(data => {
                // Handle response from server
                if (data.exists) {
                    document.getElementById("emailValidationMessage").textContent = "Email already exists";
                } else {
                    document.getElementById("emailValidationMessage").textContent = "";
                }
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
    }
    // Password validation
    document.getElementById("password").addEventListener("input", function () {
        var passwordField = this;
        var password = passwordField.value;
        var passwordValidationMessage = document.getElementById("passwordValidationMessage");
        if (password.trim() === "") {
            passwordValidationMessage.textContent = "";
            return; // Exit the function if the password is empty
        }
        var requirements = checkPasswordRequirements(password);
        if (requirements.length > 0) {
            passwordValidationMessage.textContent = "Password must have:\n" + requirements.join("\n");
        } else {
            passwordValidationMessage.textContent = "";
        }
    });


    // Function to check password requirements
    function checkPasswordRequirements(password) {
        var requirements = [];
        if (password.length < 12) {
            requirements.push("12 characters");
        }
        if (!/[A-Za-z]/.test(password)) {
            requirements.push("One letter");
        }
        if (!/\d/.test(password)) {
            requirements.push("One number");
        }
        if (!/[@$!%*#?&]/.test(password)) {
            requirements.push("One special character or Strong Password");
        }
        return requirements;
    }

    // Contact number validation
    document.getElementById("contact").addEventListener("input", function () {
        var phoneField = this;
        var phone = phoneField.value;
        var phoneValidationMessage = document.getElementById("phoneValidationMessage");
        if (phone.trim() === "") {
            phoneValidationMessage.textContent = "";
            return; // Exit the function if the contact number is empty
        }
        if (!isValidPhoneNumber(phone)) {
            phoneValidationMessage.textContent = "valid Number";
        } else {
            phoneValidationMessage.textContent = "";
        }
    });

    // Function to validate contact number
    function isValidPhoneNumber(phone) {
        // Contact number must start with +639 and have 12 digits
        return /^\+639\d{9}$/.test(phone);
    }

    // Add event listener to show password checkbox
    const showPasswordCheckbox = document.getElementById("showPasswordCheckbox");
    const passwordInput = document.getElementById("password");
    showPasswordCheckbox.addEventListener("change", function() {
        if (this.checked) {
            passwordInput.type = "text";
        } else {
            passwordInput.type = "password";
        }
    });

    // Add event listener to show confirm password checkbox
    const showConfirmPasswordCheckbox = document.getElementById("showConfirmPasswordCheckbox");
    const confirmPasswordInput = document.getElementById("confirm_password");
    showConfirmPasswordCheckbox.addEventListener("change", function() {
        if (this.checked) {
            confirmPasswordInput.type = "text";
        } else {
            confirmPasswordInput.type = "password";
        }
    });
</script>
</body>
</html>
