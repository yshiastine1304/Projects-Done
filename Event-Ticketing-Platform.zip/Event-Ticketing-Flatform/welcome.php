<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EVENT PLANNING TICKETING PLATFORM</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Font Awesome for icons -->
<style>
    body {
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
        overflow: hidden;
        background-position: center; /* Center the background image */
        margin: 0; /* Remove default margin */
        font-family: Arial, sans-serif; /* Use Arial font */
    }

    header {
        background-color: #343a40;
        padding: 20px;
        text-align: center;
        color: #ffffff;
    }

    .sidebar {
        position: fixed;
        left: 0;
        top: 60px; /* Adjusted top position to make space for the header */
        height: calc(100% - 60px); /* Adjusted height to fill remaining space */
        width: 200px; /* Adjusted width */
        background-color: #343a40; /* Dark gray */
        padding-top: 20px;
    }

    .sidebar ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .sidebar ul li {
        padding: 10px 20px;
        border-bottom: 1px solid #495057; /* Dark gray */
    }

    .sidebar ul li a {
        text-decoration: none;
        color: #ffffff; /* White */
        display: block;
        font-size: 17px;
    }

    .sidebar ul li a i {
        margin-right: 10px; /* Add space between icon and text */
    }

    .sidebar ul li a:hover {
        background-color: #495057; /* Dark gray on hover */
    }

    .active {
        background-color: #007bff; /* Blue for active link */
        color: #ffffff; /* White text for active link */
    }

    .content {
        margin-left: 200px; /* Adjusted margin */
        padding: 20px;
    }

    h2 {
        color: #343a40; /* Dark gray */
    }

    footer {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: #343a40;
        color: #ffffff;
        text-align: center;
        padding: 10px 0;
    }
</style>
</head>
<body>

<header>
    <h1><i class="fas fa-calendar-alt"></i> EVENT PLANNING TICKETING PLATFORM</h1>
    <p>Welcome to our platform. Discover and attend amazing events!</p>
</header>

<div class="sidebar">
    <ul>
        <li><a href="#"><i class="fas fa-calendar-day"></i> Events</a></li>
        <li><a href="#"><i class="fas fa-layer-group"></i> Event Categories</a></li>
        <li><a href="#"><i class="fas fa-tags"></i> Event Tags</a></li>
        <li><a href="#"><i class="fas fa-map-marker-alt"></i> Locations</a></li>
        <li><a href="#"><i class="fas fa-calendar-alt"></i> Event Types</a></li>
        <li><a href="#"><i class="fas fa-chart-line"></i> Purchases Report</a></li>
        <li><a href="#"><i class="fas fa-clock"></i> Schedulers</a></li>
        <li><a href="#"><i class="fas fa-user"></i> Speakers</a></li>
        <li><a href="#"><i class="fas fa-layer-group"></i> Speaker Categories</a></li>
        <li><a href="#"><i class="fas fa-certificate"></i> License</a></li>
        <li><a href="#"><i class="fas fa-question-circle"></i> Get Help</a></li>
        <li><a href="#"><i class="fas fa-file-alt"></i> Pages</a></li>
        <li><a href="#"><i class="fas fa-comment"></i> Comments</a></li>
        <li><a href="#"><i class="fas fa-chart-bar"></i> Analytics</a></li>
        <li><a href="#"><i class="fas fa-bullhorn"></i> Marketing</a></li>
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
    </ul>
</div>

<div class="content">
    <h2>Upcoming Events</h2>
    <!-- Content for displaying upcoming events goes here -->
</div>

<footer>
    &copy; 2024 Event Planning Ticketing Platform. All rights reserved.
</footer>

<script>
    function logout() {
        // Perform logout action here, such as redirecting to logout.php
        window.location.href = "logout.php";
    }

    // Array of background images
    var backgroundImages = [
        "Ticketing.jpg",
        "ramdom.gif",
        "1.jpg"
    ];

    // Index of the current background image
    var currentIndex = 0;

    // Function to change background image
    function changeBackground() {
        document.body.style.backgroundImage = "url('" + backgroundImages[currentIndex] + "')";
        currentIndex = (currentIndex + 1) % backgroundImages.length; // Move to the next image, looping back to the start if necessary
    }

    // Change background image every 5 seconds (5000 milliseconds)
    setInterval(changeBackground, 5000);
</script>

</body>
</html>
