<?php
// Include database connection script
include 'db_con.php';

// Check if event ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: admin_dashboard.php");
    exit();
}

// Fetch event ID
$event_id = $_GET['id'];

// Prepare SQL statement to delete event
$sql = "DELETE FROM events WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $event_id);

// Execute query
if ($stmt->execute()) {
    // Redirect to admin dashboard
    header("Location: admin_dashboard.php");
    exit();
} else {
    // Handle error
    echo "Error: " . $conn->error;
}
?>
