<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Example validation: Check if email and password match expected values
    $validEmail = "reymart.gerondalan1234@gmail.com";
    $validPassword = "aa@@0909335360709";

    if ($email == $validEmail && $password == $validPassword) {
        // Valid credentials, redirect to admin dashboard
        header("Location: admin_dashboard.php");
        exit();
    } else {
        // Invalid credentials, display error message
        echo "<script>
                document.getElementById('error-message').style.display = 'block';
              </script>";
    }
}
?>
