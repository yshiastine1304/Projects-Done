<?php

$email = $_POST["email"];

// Generate a random OTP (6 digits)
$otp = sprintf('%06d', mt_rand(0, 999999));

// Hash the OTP (optional, but can be useful for storing securely)
$otp_hash = password_hash($otp, PASSWORD_DEFAULT);

// Set the OTP expiry time (e.g., 30 minutes from now)
$expiry = date("Y-m-d H:i:s", time() + 60 * 30);

echo "Expiry: $expiry"; // Debugging line to check the format of $expiry

// Establish a MySQLi connection
$mysqli = new mysqli("localhost", "root", "", "reymart.event_db");

$sql = "UPDATE users
        SET reset_otp_hash = ?,
            reset_otp_expires_at = ?
        WHERE email = ?";

$stmt = $mysqli->prepare($sql);

// Check if $stmt is valid
if ($stmt === false) {
    die("Error: " . $mysqli->error);
}

$stmt->bind_param("sss", $otp_hash, $expiry, $email);

$stmt->execute();

if ($mysqli->affected_rows) {

    $mail = require __DIR__ . "/mailer.php";

    $mail->setFrom("anonymous@gmail.com");
    $mail->addAddress($email);
    $mail->Subject = "Password Reset OTP";
    $mail->Body = "Your password reset OTP is: $otp. This OTP is valid for 1 minutes.";

    try {

        $mail->send();

    } catch (Exception $e) {

        echo "Message could not be sent. Mailer error: {$mail->ErrorInfo}";

    }

}

echo "<script>alert('Reset OTP sent, please check your inbox.'); window.location.href = 'index.php';</script>";
exit;
