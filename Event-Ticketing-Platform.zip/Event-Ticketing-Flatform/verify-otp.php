<?php

$email = $_POST["email"];
$otp = $_POST["otp"];
$new_password = $_POST["new_password"];
$confirm_password = $_POST["confirm_password"];

// Validate if passwords match
if ($new_password !== $confirm_password) {
    die("Passwords do not match.");
}

$mysqli = new mysqli("localhost", "root", "", "reymart.event_db");

// Fetch user by email
$sql = "SELECT reset_otp_hash, reset_otp_expires_at FROM users WHERE email = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($otp_hash, $otp_expiry);
    $stmt->fetch();

    // Verify OTP and its expiry
    if (password_verify($otp, $otp_hash) && strtotime($otp_expiry) > time()) {
        // Hash the new password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Update user's password
        $update_sql = "UPDATE users SET password = ? WHERE email = ?";
        $update_stmt = $mysqli->prepare($update_sql);
        $update_stmt->bind_param("ss", $hashed_password, $email);
        $update_stmt->execute();

        // Check if password was updated successfully
        if ($update_stmt->affected_rows) {
            echo "<script>alert('Password updated successfully.'); window.location.href = 'index.php';</script>";
            exit;
        } else {
            echo "Failed to update password.";
        }
        
        // Close the update statement
        $update_stmt->close();
    } else {
        echo "Invalid or expired OTP.";
    }
} else {
    echo "User not found.";
}

$stmt->close();
$mysqli->close();
?>