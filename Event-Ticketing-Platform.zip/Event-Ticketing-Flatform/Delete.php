<?php
// Include your database connection file
include('db_connection.php');

// Retrieve data from a form or elsewhere
$id = $_POST['id'];

// Prepare the SQL statement
$sql = "DELETE FROM users WHERE id = ?";

// Prepare and execute the statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

// Check if the deletion was successful
if ($stmt->affected_rows > 0) {
    echo "Administrator deleted successfully.";
} else {
    echo "Failed to delete administrator.";
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
